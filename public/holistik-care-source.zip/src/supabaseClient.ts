import { createClient } from '@supabase/supabase-js';

const supabaseUrl = (import.meta as any).env?.VITE_SUPABASE_URL || 'https://ypfjzxibzhqehppmxifw.supabase.co';
const supabaseAnonKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || 'sb_publishable_Hq0JjbvwsH0G7Wt0Hq6KLQ_BbCbnvFp';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
